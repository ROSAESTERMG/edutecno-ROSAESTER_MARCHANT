<template>
  <div class="ultimo">
   <h1>ULTIMO POST</h1>
<Pagina/>
  </div>
</template>


<script>
import Pagina from "@/components/Paginas.vue"
export default {
components:{
  Pagina
}
}
</script>
